import java.io.File;

/**
 * Created by confroom915 on 20.12.2014.
 */
public class CDCommand implements Command {
    @Override
    public File execute(File currentFile, String[] args) {
        return new File(currentFile, args[1]);
    }
}
