/**
 * Created by confroom915 on 20.12.2014.
 */
public class Commands {

    public static final String EXIT = "exit";
    public static final String LS = "ls";
    public static final String CD = "cd";
    public static final String VIM = "vim";
}
