import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {

    public List list = new ArrayList();

    public static void main(String[] args) {
        new Car("", "").test();
    }

    public void test(int j) {
        new Car("","").getList();

        Integer integer = new Integer(10);
        int i;
        list.add(integer);
    }
}
