/**
 * Created by confroom915 on 12.12.2014.
 */
public class Test {

    private int i;

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
}
