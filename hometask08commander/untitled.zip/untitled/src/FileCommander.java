import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by confroom915 on 20.12.2014.
 */
public class FileCommander {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        CommandManager commandManager = new CommandManager();
        File file = new File(".");
        while (true) {
            System.out.print(">");
            String command = scanner.nextLine();
            String[] strings = command.split(" ");
            file = commandManager.getCommand(strings[0]).execute(file, strings);
        }
    }


}
