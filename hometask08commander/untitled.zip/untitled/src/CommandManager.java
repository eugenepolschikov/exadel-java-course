import java.util.HashMap;
import java.util.Map;

/**s
 * Created by confroom915 on 20.12.2014.
 */
public class CommandManager {
    Map<String, Command> commandMap;

    public CommandManager() {
        commandMap = new HashMap<String, Command>();
        commandMap.put(Commands.LS, new LSCommand());
        commandMap.put(Commands.EXIT, new ExitCommand());
        commandMap.put(Commands.CD, new CDCommand());
        commandMap.put(Commands.VIM, new VIMCommand());
    }

    public Command getCommand(String strCommand) {
        Command command = commandMap.get(strCommand);
        if (command == null) {
            return new UnknownCommand();
        }
        return command;
    }
}
