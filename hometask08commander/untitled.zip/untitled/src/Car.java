import java.util.ArrayList;
import java.util.List;

/**
 * Created by confroom915 on 17.12.2014.
 */
public class Car extends Vheecle {
// ------------------
    int DEFAULT_COUNT = 4;

// ------------------

    private List list = new ArrayList();

    String color, engine;
    int wheelCount = DEFAULT_COUNT;

    int temp;

    public Car(String color, String engine) {
        super();
        this.color = color;
        this.engine = engine;
        initialize();
    }

    public void initialize() {
        temp = 34;
        list.add(2);
    }

    public List getList() {
        return list;
    }

    public int test() {
        int i = 1;

        try {
            if (1 < 5) {
                i = 2;
                throw new Exception();
            }

        } catch (Exception e) {
            i = 3;


        } finally {
            i = 4;

            return i;
        }
     }

    public Car(String color, String engine, int wheelCount) {
        this(color, engine);
        this.wheelCount = wheelCount;
    }
}

