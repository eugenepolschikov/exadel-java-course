import java.io.File;

/**
 * Created by confroom915 on 20.12.2014.
 */
public class ExitCommand implements Command {
    @Override
    public File execute(File currentFile, String[] args) {
        System.exit(0);
        return currentFile;
    }
}
