import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by confroom915 on 20.12.2014.
 */
public class LSCommand implements Command {
    @Override
    public File execute(File currentFile, String[] args) {
        List<File> fileList = new ArrayList<File>();
        List<File> folderList = new ArrayList<File>();        ;
        for (File iFile : currentFile.listFiles()) {
            if (iFile.isDirectory()) {
                folderList.add(iFile);
            } else {
                fileList.add(iFile);
            }
        }

        for (File iFile : folderList) {
            System.out.println("[] " + iFile.getName());
        }

        for (File iFile : fileList) {
            System.out.println(iFile.getName());
        }
        return currentFile;
    }
}
