/**
 * Created by confroom915 on 17.12.2014.
 */
public class StringException extends Exception {
}
