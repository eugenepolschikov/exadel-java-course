import java.io.File;

/**
 * Created by confroom915 on 20.12.2014.
 */
public class UnknownCommand implements Command {

    @Override
    public File execute(File currentFile, String[] args) {
        System.out.println("Unknown command");
        return currentFile;
    }
}
