import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Scanner;

/**
 * Created by confroom915 on 20.12.2014.
 */
public class VIMCommand implements Command {
    @Override
    public File execute(File currentFile, String[] args) {
        try {
            File readFile = new File(currentFile, args[1]);
            InputStream inputStream = new FileInputStream(readFile);
            Scanner scanner = new Scanner(inputStream);
            while (scanner.hasNext()) {
                System.out.println(scanner.next());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return currentFile;
    }
}
